from flask import Flask , render_template ,url_for,redirect,request,session,flash
import mysql.connector as mysql
from passlib.hash import sha256_crypt 

sql = mysql.connect(host='localhost',user = 'linux',password='data',database='adhesion')


app = Flask(__name__)
app.secret_key = "mukoko"

#--------------PAGE D'ACCUEIL

@app.route('/')
@app.route('/index')
def index():
    return render_template('index2.html')
"""

@app.route('/admin')
def admin():
    global sql
    cur = sql.cursor()
    cur.execute("select * from members ")
    data = cur.fetchall()

    #nombres des personnes par commune

    nbr_count = cur.fetchone()

    c = sql.cursor()
    c.execute("select * from members where commune = 'kimbaseke' ")
    cc = c.fetchall()


    #nombre des garcons

    f= sql.cursor()
    f.execute("select * from members where sexe = 'masculin'")
    f.fetchall()
    ff = f.fetchone()


    #return render_template('admin.html',username = session['username'])
    return render_template('admin.html',data = data ,nbr_count = cur.rowcount,c = c.rowcount, fille =f.rowcount)

"""

#****************PAGE LOGIN
@app.route("/login")
def login():
    return render_template('login.html')


@app.route('/login_two',methods = ['GET','POST'])
def login_two():
    global sql
    message = ""

    if request.method == 'POST':
        username  = request.form['username']
        password = request.form['password']

        cu = sql.cursor()
        cu.execute("SELECT * FROM user WHERE username = %s AND password = %s ",(username,password,))
        record = cu.fetchone()
        if record:
            session['name'] = True
            session['username'] = record[1]
            return render_template('index3.html')
        else:
            flash("erreur d'authentification".title())
    #return render_template('login.html',message = messag)
    return render_template('login.html')

#----deconnexion

@app.route("/deco")
def deco():
    session.pop('name',None)
    session.pop('username',None)
    return redirect(url_for('login_two'))


#*************** register
@app.route("/member")
def member():
    return render_template('register_member.html')

@app.route('/register_send',methods=['POST'])
def register_send():

    global sql


    if request.method == "POST":
        nom = request.form['nom']
        postnom = request.form['postnom']
        prenom = request.form['prenom']
        sexe = request.form['sexe']
        civilite = request.form['civilite']
        adresse = request.form['adresse']
        commune = request.form['commune']
        telephone = request.form['telephone']
        formation = request.form['formation']

        #caste le phone en lettre
        phone =str(telephone)
        if len(phone) < 9:
            flash("le nombre de chiffre doivent etre plus 9 chiffres")
        else:
            cur = sql.cursor()
            cur.execute("INSERT INTO members(noms,postnom,prenom,sexe,civilite,adresse,commune,telephone,formations)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)",(nom,postnom,prenom,sexe,civilite,adresse,commune,phone,formation))
            sql.commit()
            cur.close()

            #return redirect(url_for('home2'))

    return redirect(url_for('home2'))


# PARTIE TEMPLATE EXTERNE

@app.route('/home')
def home2():
    return render_template('index2.html')



#DASHBOARD PARTI
@app.route('/index3')
def index3():
    global sql

    cur = sql.cursor()
    cur.execute("select * from members ")
    data = cur.fetchall()

    #

    f= sql.cursor()
    f.execute("select * from members where sexe = 'masculin'")
    f.fetchall()
    ff = f.fetchone()

    #nombre des personnes en auto-ecole

    ff= sql.cursor()
    ff.execute("select * from members where formations = 'auto-ecole'")
    ff.fetchall()
    fff = ff.fetchone()

    #nombre des personnes en informatique

    nbr_count = cur.fetchone()
    c = sql.cursor()
    c.execute("select * from members where formations = 'informatique' ")
    cc = c.fetchall()

    #nombre des personnes en coupe et couture

    ms = sql.cursor()
    ms.execute("select * from members where formations = 'coupe et couture' ")
    cc = ms.fetchall()

    #nombre de personne de la commune de djili
    dj = sql.cursor()
    dj.execute(" select * from members where commune not in ('masina','kimbaseke','lemba','limete') "  )
    dj_on = dj.fetchall()


    #nombre de personne de la commune de kimbaseke
    dj2 = sql.cursor()
    dj2.execute(" select * from members where commune ='kimbaseke' "  )
    dj_on2 = dj2.fetchall()

    #nombre de personne de la commune de kimbaseke
    dj3 = sql.cursor()
    dj3.execute(" select * from members where commune ='masina' "  )
    dj_on3 = dj3.fetchall()


    #nombre de personne de la commune de kimbaseke
    d = sql.cursor()
    d.execute(" select * from members "  )
    dd = d.fetchall()

    return render_template('index3.html', fille =ff.rowcount,
                                          data = data,
                                          dt = d.rowcount,
                                          kimb = c.rowcount,
                                          mas=ms.rowcount,
                                          dji = dj.rowcount,
                                          dji2 = dj2.rowcount,
                                          dji3 = dj3.rowcount)

#PARTI LOGIN DASH
@app.route('/login3')
def login3():
    return render_template('signin3.html')

@app.route('/table')
def table3():
    return render_template('table3.html')


#PARTIE SUPPRESSION ET MODIFICATION

@app.route('/modify/<string:member>',methods=['GET','POST'])
def modify(member):


    if request.method == "POST":
        nom = request.form['nom']
        postnom = request.form['postnom']
        prenom = request.form['prenom']
        sexe = request.form['sexe']
        civilite = request.form['civilite']
        adresse = request.form['adresse']
        commune = request.form['commune']
        telephone = request.form['telephone']
        formation = request.form['formation']
        #caste le phone en lettre
        phone =str(telephone)
        cur = sql.cursor()
        cur.execute("UPDATE members SET noms = %s,postnom= %s,prenom = %s,sexe = %s,civilite = %s,adresse = %s,commune = %s,telephone = %s ,formations = %s where member =%s",
        (nom,postnom,prenom,sexe,civilite,adresse,commune,phone,formation,member))
        sql.commit()
        cur.close()

        return redirect(url_for('index3'))

    cur = sql.cursor()
    cur.execute("select * from members WHERE member = %s",[member])
    r = cur.fetchone()
    return render_template('modify.html',update = r)



@app.route('/delete/<string:member>',methods = ['GET','POST'])
def delete(member):

    #recuperation
    cur = sql.cursor()
    cur.execute("DELETE FROM members WHERE member = %s",[member])
    sql.commit()
    cur.close()
    return redirect(url_for('index3'))



@app.route('/add')
def add():
    #recuperation des chef de membres
    chief = sql.cursor()
    chief.execute("select * from chef")

    ch = chief.fetchall()



    return render_template('add.html' , rec = ch)
# Enregistrement des cellules
@app.route('/chef')
def chef():
    #provinces recuperation pour la boucle

    pro = sql.cursor()
    pro.execute('select * from provinces')

    aff_pr = pro.fetchall()
    return render_template('chief.html', aff = aff_pr)


@app.route('/chef_send',methods=["POST"])
def chef_send():
    if request.method == 'POST':
        nom             = request.form['nom']
        postnom         = request.form['postnom']
        prenom          = request.form['prenom']
        adresse         = request.form['adresse']
        phone           = request.form['phone']
        commune         = request.form['commune']
        sexe            = request.form['sexe']
        civilite        = request.form['civilite']
        naissance       = request.form['nai']
        lieu            = request.form['lieu']
        secteur         = request.form['secteur']
        territoire      = request.form['territoire']
        province        = request.form['province']
        cellule         = request.form['cellule']
        pwd             = request.form['pwd'] 
        cnf             = request.form['conf'] 
        
        
        sec = sha256_crypt.encrypt(str(pwd))
         
        
        if pwd != cnf:
            flash("le mot de passe doit etre conforme") 
            return redirect(url_for('chef')) 
                
        else:
            
            tel = str(phone)

            send = sql.cursor()
            send.execute("insert into chef(nom,postnom,prenom,adresse,telephone,commune,sexe,civilite,date_nai,lieu_nai,secteur,territoire,province,cellule,pwd)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (nom,postnom,prenom,adresse,tel,commune,sexe,civilite,naissance,lieu,secteur,territoire,province,cellule,sec))
            sql.commit()
            send.close()
            # flash('enregistrement reussi')
            return redirect(url_for('chef_login'))


    return 'hello'


@app.route('/chef_login',methods=["GET","POST"])
def chef_login():
    
    if request.method == "POST":
        name = request.form['login']
        pwd  = request.form['pw']
        
        
        
        # cur = sql.cursor()
        # cur.execute("select nom from chef where nom = %s",(name))
        # namedate = cur.fetchone()
        
        
        # c = sql.cursor()
        # c.execute("select pwd from chef where pwd = %s",(pwd))
        # pwddate = c.fetchone()
        
        
        cu = sql.cursor()
        cu.execute("SELECT * FROM chef WHERE nom = %s AND pwd = %s",(name,pwd)) 
        
        record = cu.fetchone()
        
        if  record :
            session['name'] = True
            # session['username'] = record[1]
            
            return redirect(url_for('chef'))
        else:
            return 'hello'
            
       
        
        # if namedate is None:
        #     flash('ce nom ne pas dans la base de donne')
        #     return render_template('loginC.html')
        # else:
        #     for d in pwddate:
        #         if sha256_crypt.verify(pwd,d):
        #             flash('success')
        #             return redirect(url_for('chef'))
        #         else:
        #             return render_template('loginC.html')
        
    
    return render_template('loginC.html')












#ACTIVATION DU SERVER

if __name__ == '__main__':
    app.run(port =2022,debug = True)
